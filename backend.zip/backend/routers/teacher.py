from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func
from sqlalchemy.orm import Session
from datetime import datetime, timezone
from typing import List

from backend import models, schemas, auth
from backend.database import get_db

router = APIRouter(prefix="/teacher", tags=["Teacher"])

def get_utc_now():
    return datetime.now(timezone.utc).replace(tzinfo=None)

def normalize_pagination(page: int = 1, page_size: int = 50, max_page_size: int = 200) -> tuple[int, int, int]:
    safe_page = max(1, int(page or 1))
    safe_page_size = max(1, min(int(page_size or 50), int(max_page_size)))
    offset = (safe_page - 1) * safe_page_size
    return safe_page, safe_page_size, offset

def to_utc_iso(dt):
    if not dt:
        return None
    return dt.replace(tzinfo=timezone.utc).isoformat()

def ensure_questions_mutable(quiz_id: int, db: Session):
    """
    Prevent quiz question edits once any student has started an attempt.

    Otherwise, existing sessions can end up with `question_order` IDs that no
    longer exist, causing students to see fewer questions (and an early Submit).
    """
    has_any_session = db.query(models.QuizSession.id).filter(models.QuizSession.quiz_id == quiz_id).first()
    if has_any_session:
        raise HTTPException(
            status_code=409,
            detail="Quiz questions cannot be modified after students have started attempts"
        )

# ==========================================
# ASSIGNMENTS
# ==========================================

@router.get("/assignments")
def get_my_assignments(db: Session = Depends(get_db), teacher: models.User = Depends(auth.get_current_teacher)):
    assigns = db.query(models.TeacherAssignment).filter_by(teacher_id=teacher.id).all()
    return [{
        "class_id": a.class_id,
        "class_name": db.query(models.Class).get(a.class_id).name,
        "subject_id": a.subject_id,
        "subject_name": db.query(models.Subject).get(a.subject_id).name,
        "subject_code": db.query(models.Subject).get(a.subject_id).code
    } for a in assigns]

# ==========================================
# QUIZZES
# ==========================================

@router.post("/quizzes", response_model=schemas.QuizResponse)
def create_quiz(quiz: schemas.QuizCreate, db: Session = Depends(get_db), teacher: models.User = Depends(auth.get_current_teacher)):
    assignment = db.query(models.TeacherAssignment).filter_by(
        teacher_id=teacher.id, 
        subject_id=quiz.subject_id
    ).first()
    
    if not assignment:
        raise HTTPException(status_code=403, detail="Not authorized for this subject.")

    quiz_data = quiz.model_dump()
    # Handle dates: Convert to UTC and make naive for MySQL storage
    if quiz_data.get("available_from"):
        quiz_data["available_from"] = quiz_data["available_from"].astimezone(timezone.utc).replace(tzinfo=None)
    if quiz_data.get("available_until"):
        quiz_data["available_until"] = quiz_data["available_until"].astimezone(timezone.utc).replace(tzinfo=None)

    is_published_val = quiz_data.pop("is_published", False)

    new_quiz = models.Quiz(
        **quiz_data,
        created_by=teacher.id,
        is_published=is_published_val
    )
    
    db.add(new_quiz)
    db.commit()
    db.refresh(new_quiz)
    return new_quiz

@router.get("/quizzes", response_model=List[schemas.QuizResponse])
def list_my_quizzes(db: Session = Depends(get_db), teacher: models.User = Depends(auth.get_current_teacher)):
    return db.query(models.Quiz).filter(models.Quiz.created_by == teacher.id).all()

@router.get("/quizzes/{quiz_id}", response_model=schemas.QuizResponse)
def get_quiz_detail(quiz_id: int, db: Session = Depends(get_db), teacher: models.User = Depends(auth.get_current_teacher)):
    quiz = db.query(models.Quiz).filter(models.Quiz.id == quiz_id, models.Quiz.created_by == teacher.id).first()
    if not quiz:
        raise HTTPException(status_code=404, detail="Quiz not found")
    return quiz

@router.patch("/quizzes/{quiz_id}/toggle-status")
def toggle_quiz_status(quiz_id: int, db: Session = Depends(get_db), teacher: models.User = Depends(auth.get_current_teacher)):
    """Safe toggle that does not touch available_from/until dates."""
    quiz = db.query(models.Quiz).filter(models.Quiz.id == quiz_id, models.Quiz.created_by == teacher.id).first()
    if not quiz:
        raise HTTPException(status_code=404, detail="Quiz not found")
    
    quiz.is_published = not quiz.is_published
    db.commit()
    return {"is_published": quiz.is_published}

# ==========================================
# ELIGIBLE CLASSES
# ==========================================

@router.get("/quizzes/{quiz_id}/eligible-classes")
def get_eligible_classes(quiz_id: int, db: Session = Depends(get_db), teacher: models.User = Depends(auth.get_current_teacher)):
    quiz = db.query(models.Quiz).get(quiz_id)
    if not quiz or quiz.created_by != teacher.id:
        raise HTTPException(403)

    assigns = db.query(models.TeacherAssignment).filter_by(
        teacher_id=teacher.id,
        subject_id=quiz.subject_id
    ).all()
    
    return [{
        "id": a.class_id,
        "name": db.query(models.Class).get(a.class_id).name,
        "code": db.query(models.Class).get(a.class_id).code
    } for a in assigns]

@router.get("/quizzes/{quiz_id}/assigned-classes")
def get_quiz_assigned_class_ids(quiz_id: int, db: Session = Depends(get_db), teacher: models.User = Depends(auth.get_current_teacher)):
    links = db.query(models.QuizClass).filter_by(quiz_id=quiz_id).all()
    return [link.class_id for link in links]

# ==========================================
# QUESTIONS
# ==========================================

@router.get("/quizzes/{quiz_id}/questions", response_model=List[schemas.QuestionResponse])
def get_quiz_questions(quiz_id: int, db: Session = Depends(get_db), teacher: models.User = Depends(auth.get_current_teacher)):
    return db.query(models.Question).filter(models.Question.quiz_id == quiz_id).all()

@router.post("/quizzes/{quiz_id}/questions", response_model=schemas.QuestionResponse)
def add_question(quiz_id: int, question: schemas.QuestionCreate, db: Session = Depends(get_db), teacher: models.User = Depends(auth.get_current_teacher)):
    quiz = db.query(models.Quiz).filter(models.Quiz.id == quiz_id, models.Quiz.created_by == teacher.id).first()
    if not quiz:
        raise HTTPException(status_code=403, detail="Not authorized")

    ensure_questions_mutable(quiz_id, db)

    new_question = models.Question(quiz_id=quiz_id, **question.model_dump())
    db.add(new_question)
    db.commit()
    db.refresh(new_question)
    return new_question

@router.post("/quizzes/{quiz_id}/questions/bulk")
def bulk_add_questions(quiz_id: int, questions: List[schemas.QuestionCreate], db: Session = Depends(get_db), teacher: models.User = Depends(auth.get_current_teacher)):
    quiz = db.query(models.Quiz).filter(models.Quiz.id == quiz_id, models.Quiz.created_by == teacher.id).first()
    if not quiz:
        raise HTTPException(status_code=403, detail="Not authorized")

    ensure_questions_mutable(quiz_id, db)

    if not questions:
        raise HTTPException(status_code=400, detail="No questions provided")

    max_order = db.query(models.func.max(models.Question.order_index)).filter_by(quiz_id=quiz_id).scalar()
    start_order = int(max_order or 0) + 1

    new_rows: list[models.Question] = []
    for idx, q in enumerate(questions, start=1):
        q_type = (q.type or "").strip().lower()
        body = (q.body or "").strip()
        if not body:
            raise HTTPException(status_code=400, detail=f"Row {idx}: body is required")

        points = int(q.points or 1)
        if points <= 0:
            raise HTTPException(status_code=400, detail=f"Row {idx}: points must be > 0")

        options = q.options
        correct_answer = q.correct_answer

        if q_type == "mcq":
            clean_options = [(o or "").strip() for o in (options or [])]
            clean_options = [o for o in clean_options if o]
            if len(clean_options) < 2:
                raise HTTPException(status_code=400, detail=f"Row {idx}: MCQ requires at least 2 options")
            if not (correct_answer or "").strip():
                raise HTTPException(status_code=400, detail=f"Row {idx}: MCQ correct_answer is required")
            correct_answer = correct_answer.strip()
            if correct_answer not in clean_options:
                raise HTTPException(status_code=400, detail=f"Row {idx}: correct_answer must match one of the options")
            options = clean_options

        elif q_type == "qa":
            options = None
            correct_answer = None

        else:
            raise HTTPException(status_code=400, detail=f"Row {idx}: invalid type '{q.type}' (use mcq or qa)")

        new_rows.append(models.Question(
            quiz_id=quiz_id,
            body=body,
            type=q_type,
            options=options,
            correct_answer=correct_answer,
            points=points,
            order_index=start_order + idx - 1
        ))

    db.add_all(new_rows)
    db.commit()
    return {"status": "ok", "added": len(new_rows)}

# ==========================================
# ASSIGNMENTS
# ==========================================

@router.post("/quizzes/{quiz_id}/assign")
def assign_quiz_to_classes(quiz_id: int, assignment: schemas.QuizAssign, db: Session = Depends(get_db), teacher: models.User = Depends(auth.get_current_teacher)):
    quiz = db.query(models.Quiz).filter(models.Quiz.id == quiz_id, models.Quiz.created_by == teacher.id).first()
    if not quiz:
        raise HTTPException(status_code=403, detail="Not authorized")

    db.query(models.QuizClass).filter(models.QuizClass.quiz_id == quiz_id).delete()
    for class_id in assignment.class_ids:
        db.add(models.QuizClass(quiz_id=quiz_id, class_id=class_id))
    
    quiz.is_published = True
    db.commit()
    return {"message": "Quiz assigned and published"}

# ==========================================
# RESULTS & GRADING
# ==========================================

@router.get("/quizzes/{quiz_id}/results")
def get_quiz_results(quiz_id: int, db: Session = Depends(get_db), teacher: models.User = Depends(auth.get_current_teacher)):
    quiz = db.query(models.Quiz).filter_by(id=quiz_id).first()
    sessions = db.query(models.QuizSession).filter_by(quiz_id=quiz_id).all()
    
    res_list = []
    any_flag_repairs = False
    for s in sessions:
        student = db.query(models.User).get(s.user_id)
        class_link = db.query(models.QuizClass).filter_by(quiz_id=quiz_id).first()
        class_obj = db.query(models.Class).get(class_link.class_id) if class_link else None
        
        # Get cheat events for this session
        cheat_events = db.query(models.CheatEvent).filter_by(session_id=s.id).order_by(models.CheatEvent.occurred_at).all()
        computed_flag_count = len(cheat_events)
        if s.cheat_flag_count != computed_flag_count:
            s.cheat_flag_count = computed_flag_count
            any_flag_repairs = True
        cheat_events_list = [{
            "id": e.id,
            "event_type": e.event_type,
            "occurred_at": e.occurred_at.isoformat() if e.occurred_at else None,
            "detail": e.detail
        } for e in cheat_events]
        
        # Calculate total points and pass/fail status
        total_points_raw = db.query(models.Question).filter_by(quiz_id=quiz_id).with_entities(models.func.sum(models.Question.points)).scalar()
        total_points = float(total_points_raw or 0)
        effective_score = s.score_override if s.score_override is not None else (s.score or 0)
        percentage_score = (effective_score / total_points * 100) if total_points > 0 else 0
        is_passed = percentage_score >= quiz.pass_percentage
        
        res_list.append({
            "id": s.id,
            "class_name": class_obj.name if class_obj else "General",
            "student_name": student.display_name,
            "registration_id": student.registration_id,
            "status": s.status,
            "score": effective_score,
            "raw_score": s.score,
            "is_score_overridden": s.score_override is not None,
            "score_override_reason": s.score_override_reason,
            "total_points": total_points,
            "result_released": s.result_released,
            "cheat_flag_count": computed_flag_count,
            "cheat_events": cheat_events_list,
            "pass_percentage": quiz.pass_percentage,
            "percentage_score": round(percentage_score, 1),
            "is_passed": is_passed
        })

    if any_flag_repairs:
        db.commit()
    return {"quiz": {"title": quiz.title}, "sessions": res_list}

@router.get("/quizzes/{quiz_id}/results/paged")
def get_quiz_results_paged(
    quiz_id: int,
    page: int = 1,
    page_size: int = 25,
    db: Session = Depends(get_db),
    teacher: models.User = Depends(auth.get_current_teacher)
):
    safe_page, safe_page_size, offset = normalize_pagination(page, page_size, max_page_size=200)

    quiz = db.query(models.Quiz).filter_by(id=quiz_id).first()
    if not quiz:
        raise HTTPException(status_code=404, detail="Quiz not found")

    # Single class label (best-effort) for this quiz
    class_link = db.query(models.QuizClass).filter_by(quiz_id=quiz_id).order_by(models.QuizClass.class_id.asc()).first()
    class_obj = db.query(models.Class).get(class_link.class_id) if class_link else None
    class_name = class_obj.name if class_obj else "General"

    total_points_raw = db.query(models.Question).filter_by(quiz_id=quiz_id).with_entities(func.sum(models.Question.points)).scalar()
    total_points = float(total_points_raw or 0)

    base = db.query(models.QuizSession).filter_by(quiz_id=quiz_id)
    total = base.count()
    sessions = base.order_by(models.QuizSession.id.desc()).offset(offset).limit(safe_page_size).all()

    session_ids = [s.id for s in sessions]
    cheat_events = []
    if session_ids:
        cheat_events = db.query(models.CheatEvent).filter(models.CheatEvent.session_id.in_(session_ids))\
            .order_by(models.CheatEvent.occurred_at).all()

    events_by_session: dict[int, list[models.CheatEvent]] = {}
    for e in cheat_events:
        events_by_session.setdefault(e.session_id, []).append(e)

    # Fetch students for page in one query
    student_ids = [s.user_id for s in sessions]
    students = db.query(models.User.id, models.User.display_name, models.User.registration_id)\
        .filter(models.User.id.in_(student_ids)).all() if student_ids else []
    student_map = {u.id: u for u in students}

    any_flag_repairs = False
    items = []
    for s in sessions:
        u = student_map.get(s.user_id)
        events = events_by_session.get(s.id, [])
        computed_flag_count = len(events)
        if s.cheat_flag_count != computed_flag_count:
            s.cheat_flag_count = computed_flag_count
            any_flag_repairs = True

        effective_score = float(s.score_override if s.score_override is not None else (s.score or 0))
        percentage_score = (effective_score / total_points * 100) if total_points > 0 else 0
        is_passed = percentage_score >= float(quiz.pass_percentage or 0)

        items.append({
            "id": s.id,
            "class_name": class_name,
            "student_name": (u.display_name if u else "Unknown"),
            "registration_id": (u.registration_id if u else "unknown"),
            "status": s.status,
            "score": effective_score,
            "raw_score": s.score,
            "is_score_overridden": s.score_override is not None,
            "score_override_reason": s.score_override_reason,
            "total_points": total_points,
            "result_released": s.result_released,
            "cheat_flag_count": computed_flag_count,
            "cheat_events": [{
                "id": e.id,
                "event_type": e.event_type,
                "occurred_at": to_utc_iso(e.occurred_at),
                "detail": e.detail
            } for e in events],
            "pass_percentage": float(quiz.pass_percentage or 0),
            "percentage_score": round(percentage_score, 1),
            "is_passed": is_passed
        })

    if any_flag_repairs:
        db.commit()

    return {"quiz": {"title": quiz.title}, "items": items, "total": total, "page": safe_page, "page_size": safe_page_size}

@router.get("/sessions/{session_id}/grade")
def get_session_grading(session_id: int, db: Session = Depends(get_db), teacher: models.User = Depends(auth.get_current_teacher)):
    results = db.query(models.Answer, models.Question).join(
        models.Question, models.Answer.question_id == models.Question.id
    ).filter(
        models.Answer.session_id == session_id,
        models.Question.type == "qa",
        models.Answer.graded_at == None
    ).all()

    return [{
        "id": ans.id,
        "question_body": q.body,
        "max_points": q.points,
        "answer_value": ans.answer_value,
        "marks_awarded": ans.marks_awarded,
        "is_overridden": ans.is_overridden
    } for ans, q in results]

@router.get("/sessions/{session_id}/grade/paged")
def get_session_grading_paged(
    session_id: int,
    page: int = 1,
    page_size: int = 10,
    db: Session = Depends(get_db),
    teacher: models.User = Depends(auth.get_current_teacher)
):
    safe_page, safe_page_size, offset = normalize_pagination(page, page_size, max_page_size=100)

    base = db.query(models.Answer, models.Question).join(
        models.Question, models.Answer.question_id == models.Question.id
    ).filter(
        models.Answer.session_id == session_id,
        models.Question.type == "qa",
        models.Answer.graded_at == None
    )

    total = base.count()
    rows = base.order_by(models.Answer.id.asc()).offset(offset).limit(safe_page_size).all()

    items = [{
        "id": ans.id,
        "question_body": q.body,
        "max_points": q.points,
        "answer_value": ans.answer_value,
        "marks_awarded": ans.marks_awarded,
        "is_overridden": ans.is_overridden
    } for ans, q in rows]

    return {"items": items, "total": total, "page": safe_page, "page_size": safe_page_size}

@router.get("/sessions/{session_id}/detail")
def get_session_detail(
    session_id: int,
    db: Session = Depends(get_db),
    teacher: models.User = Depends(auth.get_current_teacher)
):
    session = db.query(models.QuizSession).get(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    quiz = db.query(models.Quiz).get(session.quiz_id)
    if not quiz:
        raise HTTPException(status_code=404, detail="Quiz not found")

    if teacher.role != "admin" and quiz.created_by != teacher.id:
        raise HTTPException(status_code=403, detail="Not authorized")

    student = db.query(models.User).get(session.user_id)
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    total_points_raw = db.query(models.Question).filter_by(quiz_id=quiz.id).with_entities(func.sum(models.Question.points)).scalar()
    total_points = float(total_points_raw or 0)

    effective_score = float(session.score_override if session.score_override is not None else (session.score or 0))
    percentage_score = (effective_score / total_points * 100) if total_points > 0 else 0
    is_passed = percentage_score >= float(quiz.pass_percentage or 0)

    # Questions in the session order when available (otherwise default order_index then id)
    questions = []
    if session.question_order:
        q_ids = list(session.question_order)
        rows = db.query(models.Question).filter(models.Question.id.in_(q_ids)).all()
        by_id = {q.id: q for q in rows}
        for qid in q_ids:
            q = by_id.get(qid)
            if q:
                questions.append(q)
    else:
        questions = db.query(models.Question)\
            .filter_by(quiz_id=quiz.id)\
            .order_by(models.Question.order_index.asc(), models.Question.id.asc())\
            .all()

    answers = db.query(models.Answer).filter_by(session_id=session.id).all()
    ans_map = {a.question_id: a for a in answers}

    cheat_events = db.query(models.CheatEvent).filter_by(session_id=session.id).order_by(models.CheatEvent.occurred_at).all()
    computed_flag_count = len(cheat_events)
    if session.cheat_flag_count != computed_flag_count:
        session.cheat_flag_count = computed_flag_count
        db.commit()

    return {
        "quiz": {
            "id": quiz.id,
            "title": quiz.title,
            "pass_percentage": float(quiz.pass_percentage or 0),
            "total_points": total_points
        },
        "student": {
            "id": student.id,
            "display_name": student.display_name,
            "registration_id": student.registration_id
        },
        "session": {
            "id": session.id,
            "attempt_number": session.attempt_number,
            "status": session.status,
            "started_at": to_utc_iso(session.started_at),
            "expires_at": to_utc_iso(session.expires_at),
            "submitted_at": to_utc_iso(session.submitted_at),
            "result_released": session.result_released,
            "score": session.score,
            "effective_score": effective_score,
            "percentage_score": round(percentage_score, 1),
            "is_passed": is_passed,
            "is_score_overridden": session.score_override is not None,
            "score_override_reason": session.score_override_reason,
            "score_override": session.score_override
        },
        "questions": [{
            "id": q.id,
            "body": q.body,
            "type": q.type,
            "options": q.options,
            "correct_answer": q.correct_answer,
            "points": q.points
        } for q in questions],
        "answers": {
            str(qid): {
                "answer_value": (ans_map[qid].answer_value if qid in ans_map else None),
                "answered_at": (to_utc_iso(ans_map[qid].answered_at) if qid in ans_map else None),
                "is_correct": (ans_map[qid].is_correct if qid in ans_map else None),
                "marks_awarded": (ans_map[qid].marks_awarded if qid in ans_map else None),
                "graded_at": (to_utc_iso(ans_map[qid].graded_at) if qid in ans_map else None),
                "is_overridden": (ans_map[qid].is_overridden if qid in ans_map else False)
            } for qid in [q.id for q in questions]
        },
        "cheat_flag_count": computed_flag_count,
        "cheat_events": [{
            "id": e.id,
            "event_type": e.event_type,
            "occurred_at": to_utc_iso(e.occurred_at),
            "detail": e.detail
        } for e in cheat_events]
    }

@router.post("/answers/{answer_id}/grade")
def submit_grade(answer_id: int, grade: schemas.GradeSubmit, db: Session = Depends(get_db), teacher: models.User = Depends(auth.get_current_teacher)):
    ans = db.query(models.Answer).get(answer_id)
    ans.marks_awarded = grade.marks_awarded
    ans.is_overridden = grade.is_overridden
    ans.graded_by = teacher.id
    ans.graded_at = get_utc_now()
    db.commit()
    
    session = db.query(models.QuizSession).get(ans.session_id)
    ungraded = db.query(models.Answer).join(models.Question).filter(
        models.Answer.session_id == session.id,
        models.Question.type == "qa",
        models.Answer.graded_at == None
    ).count()

    if ungraded == 0:
        session.result_released = True
        total = db.query(models.Answer).filter_by(session_id=session.id).all()
        session.score = sum([a.marks_awarded for a in total if a.marks_awarded is not None])
        db.commit()
    
    return {"message": "Grade saved"}

# ==========================================
# SESSION SCORE OVERRIDES
# ==========================================

@router.post("/sessions/{session_id}/override-zero")
def override_session_zero(session_id: int, data: schemas.SessionZeroOverride, db: Session = Depends(get_db), teacher: models.User = Depends(auth.get_current_teacher)):
    session = db.query(models.QuizSession).get(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    quiz = db.query(models.Quiz).get(session.quiz_id)
    if not quiz or quiz.created_by != teacher.id:
        raise HTTPException(status_code=403, detail="Not authorized")

    if session.status != "done":
        raise HTTPException(status_code=400, detail="Session not submitted yet")

    session.score_override = 0.0
    session.score_override_reason = data.reason
    session.score_overridden_by = teacher.id
    session.score_overridden_at = get_utc_now()
    session.result_released = True
    db.commit()

    return {"status": "ok", "score": 0.0, "is_score_overridden": True}

@router.delete("/sessions/{session_id}/override-zero")
def clear_session_zero_override(session_id: int, db: Session = Depends(get_db), teacher: models.User = Depends(auth.get_current_teacher)):
    session = db.query(models.QuizSession).get(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    quiz = db.query(models.Quiz).get(session.quiz_id)
    if not quiz or quiz.created_by != teacher.id:
        raise HTTPException(status_code=403, detail="Not authorized")

    session.score_override = None
    session.score_override_reason = None
    session.score_overridden_by = None
    session.score_overridden_at = None

    if session.status == "done":
        ungraded = db.query(models.Answer).join(models.Question).filter(
            models.Answer.session_id == session.id,
            models.Question.type == "qa",
            models.Answer.graded_at == None
        ).count()
        session.result_released = (ungraded == 0)
    else:
        session.result_released = False

    db.commit()
    return {"status": "ok", "is_score_overridden": False}

# ==========================================
# UPDATES & DELETES
# ==========================================

@router.put("/quizzes/{quiz_id}", response_model=schemas.QuizResponse)
def update_quiz(quiz_id: int, quiz_update: schemas.QuizCreate, db: Session = Depends(get_db), teacher: models.User = Depends(auth.get_current_teacher)):
    db_quiz = db.query(models.Quiz).filter(models.Quiz.id == quiz_id, models.Quiz.created_by == teacher.id).first()
    if not db_quiz:
        raise HTTPException(status_code=404, detail="Quiz not found")
    
    update_data = quiz_update.model_dump()
    
    # Standardize incoming dates to Naive UTC for MySQL
    if update_data.get("available_from"):
        update_data["available_from"] = update_data["available_from"].astimezone(timezone.utc).replace(tzinfo=None)
    if update_data.get("available_until"):
        update_data["available_until"] = update_data["available_until"].astimezone(timezone.utc).replace(tzinfo=None)

    for key, value in update_data.items():
        setattr(db_quiz, key, value)
    
    db.commit()
    db.refresh(db_quiz)
    return db_quiz

@router.delete("/quizzes/{quiz_id}")
def delete_quiz(quiz_id: int, db: Session = Depends(get_db), teacher: models.User = Depends(auth.get_current_teacher)):
    db_quiz = db.query(models.Quiz).filter(models.Quiz.id == quiz_id, models.Quiz.created_by == teacher.id).first()
    if not db_quiz:
        raise HTTPException(status_code=404, detail="Quiz not found")
    ensure_questions_mutable(quiz_id, db)
    db.delete(db_quiz)
    db.commit()
    return {"message": "Quiz deleted"}

@router.put("/questions/{question_id}", response_model=schemas.QuestionResponse)
def update_question(question_id: int, q_update: schemas.QuestionCreate, db: Session = Depends(get_db), teacher: models.User = Depends(auth.get_current_teacher)):
    db_q = db.query(models.Question).get(question_id)
    if not db_q:
        raise HTTPException(status_code=404, detail="Question not found")

    quiz = db.query(models.Quiz).filter(models.Quiz.id == db_q.quiz_id, models.Quiz.created_by == teacher.id).first()
    if not quiz:
        raise HTTPException(status_code=403, detail="Not authorized")

    ensure_questions_mutable(db_q.quiz_id, db)

    for key, value in q_update.model_dump().items():
        setattr(db_q, key, value)
    
    db.commit()
    db.refresh(db_q)
    return db_q

@router.delete("/questions/{question_id}")
def delete_question(question_id: int, db: Session = Depends(get_db), teacher: models.User = Depends(auth.get_current_teacher)):
    db_q = db.query(models.Question).get(question_id)
    if not db_q:
        raise HTTPException(status_code=404, detail="Question not found")

    quiz = db.query(models.Quiz).filter(models.Quiz.id == db_q.quiz_id, models.Quiz.created_by == teacher.id).first()
    if not quiz:
        raise HTTPException(status_code=403, detail="Not authorized")

    ensure_questions_mutable(db_q.quiz_id, db)
    db.delete(db_q)
    db.commit()
    return {"message": "Question deleted"}
